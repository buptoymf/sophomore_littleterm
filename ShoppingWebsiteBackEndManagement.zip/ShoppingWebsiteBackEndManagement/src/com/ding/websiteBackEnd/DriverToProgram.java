package com.ding.websiteBackEnd;

public class DriverToProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WelcomeGUI program = new WelcomeGUI();
		program.build();
	}

}
