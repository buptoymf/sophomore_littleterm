
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DatabaseMetaData; 
import java.sql.ResultSet;  
import java.sql.SQLException; 

public class TestJDBC {
    private Connection conn ;
    private Statement stat ;
    
    public void showMetaData() throws Exception
	 {
    	conn = DBUtil.getConnection();
		DatabaseMetaData dbmd = conn.getMetaData();        //������������ݿ��������Ϣ
	    System.out.println("JDBC��������"+dbmd.getDriverName()+"��"+dbmd.getDriverVersion()
	            +"\nJDBC URL��"+dbmd.getURL()+"\n���ݿ⣺"+dbmd.getDatabaseProductName()
	            +"���汾��"+dbmd.getDatabaseProductVersion()+"���û�����"+dbmd.getUserName()+"\n");
	    conn.close();
	 }
    
    public void showData(String sql) throws Exception
    {
    	conn = DBUtil.getConnection();
		stat = DBUtil.getStatement(conn);
		ResultSet ret = null;
  
        try {  
            ret = stat.executeQuery(sql);//ִ����䣬�õ������  
            while (ret.next()) {  
                String uid = ret.getString(1);  
                String uid2 = ret.getString(2); 
                String uid3 = ret.getString(3); 
                String uid4 = ret.getString(4); 
                String uid5 = ret.getString(5); 
                
                System.out.println(uid + "\t"  + uid2 + "\t" + uid3 + "\t");  
            }//��ʾ����  
            ret.close();  
            stat.close();//�ر�����  
        } catch (SQLException e) {  
            e.printStackTrace();  
        }  
    }
    
	public static void main(String[] args) throws Exception
	{
		TestJDBC test = new TestJDBC();
		String sql = null; 
		
		sql = "select * from product";//SQL��� 
		test.showData(sql);
		test.showMetaData();		
	}
  
}
