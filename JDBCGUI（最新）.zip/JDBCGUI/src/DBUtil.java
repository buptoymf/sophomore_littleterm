

import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.Statement;

public class DBUtil {
	 public static final String url = "jdbc:mysql://localhost:3306/shoppingwebsitebackenddb?autoReconnect=true&useSSL=false";  
	 public static final String driver = "com.mysql.jdbc.Driver";  
	 public static final String user = "root";  
	 public static final String password = "2540be3ff";  
	  
	 public static Connection getConnection() {
		 Connection conn = null;  
		 try {  
			    Class.forName(driver);//ָ����������  
	            conn = DriverManager.getConnection(url, user, password);//��ȡ����  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }
		 return conn ;
	    }  
	 public static Statement getStatement(Connection conn){
		 try {
			 return conn.createStatement();
		 }catch (Exception e) {  
	      e.printStackTrace();
	      return null ;
		 }
	 }

}
