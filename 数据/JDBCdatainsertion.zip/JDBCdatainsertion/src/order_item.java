import java.sql.*;
import java.sql.SQLException;
import java.math.BigDecimal;


public class order_item
{
	
	public static double mul(double v1,double v2){
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }
	
	
   public static void main(String args[])
   {
	   String driver=new connection_information().driver;
       String url=new connection_information().url;
       String username=new connection_information().username;
       String password=new connection_information().password;
       
       int loop,loop2;
       
       Connection conn=null;
       Statement stmt1=null;
       Statement stmt2=null;
       Statement stmt3=null;
       Statement stmt4=null;
       
       ResultSet rs1=null; 
       ResultSet rs2=null;
       ResultSet rs3=null;
       ResultSet rs4=null;
       try
       {
           Class.forName(driver);
           conn = DriverManager.getConnection(url, username, password);
           stmt1 = conn.createStatement();
           stmt2 = conn.createStatement();
           stmt3 = conn.createStatement();
           
           
           
           String sql1="select orderNo from `order`;";
           String sql2="select distinct storeNo,productno,price from onSale;";
           String sql3;
           
           String[] orderno=new String[310000];
           String[] storeno=new String[310000];
           String[] productno=new String[310000];           
           double  pce;
           
           
           rs1=stmt1.executeQuery(sql1);
           rs2=stmt2.executeQuery(sql2);

           
          // String num1="select count(distinct storeNo,productno,price) from onSale;";
           //String num2="select count(distinct orderno) from `order`;";
           
           
           //rs3=stmt3.executeQuery(num1);
           //rs4=stmt4.executeQuery(num2);
           
           int i=0;
           
           while(rs1.next())
          {
               orderno[i]=rs1.getString("orderNo");
                i++;
          }
           
          int j=0;
          
          while(rs2.next())
         {
               storeno[j]=rs2.getString("storeNo");
               productno[j]=rs2.getString("productNo");
               //pce[j]=rs2.getDouble("price");
                j++;
         }
         
         //System.out.println(i);
         
          int prand=0;
          int num;
          
        for(loop=0;loop<50000;loop++)
       {
        	
             
        	
        	
        	sql3="select distinct productno,price from onsale where storeno =\""+ storeno[prand] +"\";";
            
            rs3=stmt3.executeQuery(sql3);
            
            num=(int)(Math.random()*20)+50;
            
           // System.out.println(num);
             
        	for(loop2=0;loop2<num;loop2++)
        	{
        		int n=(int)(Math.random()*20)+1;
                
        		

                
                String sql="insert into order_item VALUES(?,?,?,?,?)";

                PreparedStatement ps = conn.prepareStatement(sql);
                
                ps.setString(1,orderno[loop]);
                
                //System.out.println(orderno[loop] +":orderno");
                ps.setString(2,storeno[prand]);
               // System.out.println(storeno[prand] +":storeno");
                rs3.next();
                ps.setString(3,rs3.getString("productno"));
                //System.out.println(rs3.getString("productno") +":productno");
                pce=rs3.getDouble("price");
                
                double p=mul(n,pce);
                
                ps.setInt(4,n);
                ps.setDouble(5,p);
                
                ps.executeUpdate();
                
                loop++;
        	}
        	
        	prand+=25;
        	
        	
        	if(prand>j)
        		break;
        	
        	
        	
       }
        	 for(loop=50000;loop<70000;loop++)
             {
              	
                   
              	prand++;
              	
              	sql3="select distinct productno,price from onsale where storeno =\""+ storeno[prand] +"\";";
                  
                  rs3=stmt3.executeQuery(sql3);
                  
                  num=(int)(Math.random()*15)+15;
                   
              	for(loop2=0;loop2<num;loop2++)
              	{
              		int n=(int)(Math.random()*20)+1;
                      
              		
              		
                       
                      
                     
                      
                      String sql="insert into order_item VALUES(?,?,?,?,?)";

                      PreparedStatement ps = conn.prepareStatement(sql);
                      
                      ps.setString(1,orderno[loop]);
                      ps.setString(2,storeno[prand]);
                      rs3.next();
                      ps.setString(3,rs3.getString("productno"));
                      
                      pce=rs3.getDouble("price");
                      
                      double p=mul(n,pce);
                      
                      ps.setInt(4,n);
                      ps.setDouble(5,p);
                      
                      ps.executeUpdate();
                      
                      loop++;
              	}
              	prand+=25;
              	
              	if(prand>j)
            		break;
             }
             
        	 for(loop=70000;loop<i;loop++)
             {
              	
                   
              	prand++;
              	
              	sql3="select distinct productno,price from onsale where storeno =\""+ storeno[prand] +"\";";
                  
                  rs3=stmt3.executeQuery(sql3);
                  
                  num=(int)(Math.random()*10)+10;
                   
              	for(loop2=0;loop2<num;loop2++)
              	{
              		int n=(int)(Math.random()*20)+1;
                      
              		
              		
                       
                      
                     
                      
                      String sql="insert into order_item VALUES(?,?,?,?,?)";

                      PreparedStatement ps = conn.prepareStatement(sql);
                      
                      ps.setString(1,orderno[loop]);
                      ps.setString(2,storeno[prand]);
                      rs3.next();
                      ps.setString(3,rs3.getString("productno"));
                      
                      pce=rs3.getDouble("price");
                      
                      double p=mul(n,pce);
                      
                      ps.setInt(4,n);
                      ps.setDouble(5,p);
                      
                      ps.executeUpdate();
                      
                      loop++;
              	}
              	prand+=25;
              	
              	if(prand>j)
            		break;
             }
        
        	 
       // System.out.println("Completed!");
}
           catch(Exception e)
          {
                  e.printStackTrace();
          } 
          finally 
          {
                if (rs1 != null)
                { //�رս��������
	try 
               {
	          rs1.close();
               } 
               catch (SQLException e) 
              {
	    e.printStackTrace();
	}
	}			
               if (stmt1!= null) 
               { // �ر����ݿ��������
	try {
	       stmt1.close();
	} 
               catch (SQLException e) 
               {
	        e.printStackTrace();
	}
	}
                 if (rs2 != null)
		     { //�رս��������
						try {
							rs2.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
					if (stmt2!= null) { // �ر����ݿ��������
						try {
							stmt2.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
					 if (rs3 != null)
				     { //�رս��������
								try {
									rs3.close();
								} catch (SQLException e) {
									e.printStackTrace();
								}
							}
							if (stmt3!= null) { // �ر����ݿ��������
								try {
									stmt3.close();
								} 
								catch (SQLException e) {
									e.printStackTrace();
								}
							
							}
               if (rs4 != null)
                { //�رս��������
	try 
               {
	          rs4.close();
               } 
               catch (SQLException e) 
              {
	    e.printStackTrace();
	}
	}			
               if (stmt4!= null) 
               { // �ر����ݿ��������
	try {
	       stmt4.close();
	} 
               catch (SQLException e) 
               {
	        e.printStackTrace();
	}
	}
             	if (conn != null) { // �ر����ݿ����Ӷ���
	try {
	       if (!conn.isClosed()) {
				conn.close();
			       }
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
            }
   }
}