
public class connection_information {

	String driver="com.mysql.jdbc.Driver";
    String url="jdbc:mysql://127.0.0.1/shoppingwebsitebackenddb?user=root&password=2540be3ff&useSSL=false";
    String username="root";
    String password="2540be3ff";
}
